
PKG_NAME = 'grafana-snapshots'
PKG_VERSION = '0.3.1'
CONFIG_NAME = 'conf/grafana-snapshots.yml'

