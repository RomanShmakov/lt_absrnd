

grafana builtin variables and functions:

- https://grafana.com/docs/grafana/latest/dashboards/variables/variable-syntax/

- https://grafana.com/docs/grafana/latest/datasources/prometheus/template-variables/

- https://grafana.com/docs/grafana/latest/dashboards/variables/add-template-variables/#global-variables


